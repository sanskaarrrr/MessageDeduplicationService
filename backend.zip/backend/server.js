const express = require('express');
const crypto = require('crypto');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// In-memory store simulating MongoDB collection
// Each entry: { hash, message, timestamp, count, id }
const messageStore = new Map();
const messageLog = [];
let totalReceived = 0;
let totalDuplicates = 0;
let idCounter = 1;

// SHA-256 Hash Generator
function hashMessage(message) {
  return crypto.createHash('sha256').update(message).digest('hex');
}

// POST /api/messages - Submit a message
app.post('/api/messages', (req, res) => {
  const { message } = req.body;

  if (!message || typeof message !== 'string' || message.trim() === '') {
    return res.status(400).json({ error: 'Message is required and must be a non-empty string.' });
  }

  const trimmed = message.trim();
  const hash = hashMessage(trimmed);
  totalReceived++;

  if (messageStore.has(hash)) {
    // Duplicate detected
    const existing = messageStore.get(hash);
    existing.count++;
    existing.lastSeen = new Date().toISOString();
    totalDuplicates++;

    const logEntry = {
      id: idCounter++,
      message: trimmed,
      hash,
      status: 'DUPLICATE',
      timestamp: new Date().toISOString(),
      originalId: existing.id,
    };
    messageLog.unshift(logEntry);

    return res.status(200).json({
      status: 'duplicate',
      message: 'Duplicate message detected. Ignored.',
      hash,
      originalTimestamp: existing.timestamp,
      occurrences: existing.count,
    });
  }

  // Unique message
  const entry = {
    id: idCounter++,
    message: trimmed,
    hash,
    timestamp: new Date().toISOString(),
    lastSeen: new Date().toISOString(),
    count: 1,
  };
  messageStore.set(hash, entry);

  const logEntry = {
    id: entry.id,
    message: trimmed,
    hash,
    status: 'ACCEPTED',
    timestamp: entry.timestamp,
  };
  messageLog.unshift(logEntry);

  return res.status(201).json({
    status: 'accepted',
    message: 'Message accepted and stored.',
    hash,
    id: entry.id,
    timestamp: entry.timestamp,
  });
});

// GET /api/messages - Get all unique messages
app.get('/api/messages', (req, res) => {
  const messages = Array.from(messageStore.values()).sort(
    (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
  );
  res.json({ count: messages.length, messages });
});

// GET /api/messages/log - Get full activity log
app.get('/api/messages/log', (req, res) => {
  res.json({ count: messageLog.length, log: messageLog.slice(0, 100) });
});

// GET /api/stats - Get statistics
app.get('/api/stats', (req, res) => {
  res.json({
    totalReceived,
    totalUnique: messageStore.size,
    totalDuplicates,
    deduplicationRate: totalReceived > 0 ? ((totalDuplicates / totalReceived) * 100).toFixed(1) : '0.0',
  });
});

// DELETE /api/messages - Clear all messages
app.delete('/api/messages', (req, res) => {
  messageStore.clear();
  messageLog.length = 0;
  totalReceived = 0;
  totalDuplicates = 0;
  idCounter = 1;
  res.json({ message: 'All messages cleared.' });
});

// GET /api/hash - Hash a message without storing
app.post('/api/hash', (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'Message required.' });
  res.json({ hash: hashMessage(message.trim()), algorithm: 'SHA-256' });
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Message Deduplication Service running on port ${PORT}`);
});
